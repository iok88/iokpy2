from bs4 import BeautifulSoup

# soup1 = BeautifulSoup('<a></b></a>', 'html.parser')
# soup2 = BeautifulSoup('<a></b></a>', 'lxml')
# print(soup1)
# print(soup2)

with open('html/page.html', 'r') as f:
    soup = BeautifulSoup(f, 'lxml')

# print(soup)
# title = soup.title
# print(title)
# print(title.name)
# print(title.attrs)
# print(title.text)
# print(title.get_text())
# print(title.string)

# h1 = soup.h1
# print(h1)
# print(h1.attrs)
# print(h1.attrs['id'])
# print(h1['id'])
# print(h1.get('id'))
# print(h1.has_attr('id'))
# print(h1.text.strip())
# print(h1.get_text(strip=True, separator=' '))

# find() find_all()
# print(soup.a)
print(soup.find('a'))
